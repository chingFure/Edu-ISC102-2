﻿namespace _102_2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Exit_btn = new System.Windows.Forms.Button();
            this.Convert_btn = new System.Windows.Forms.Button();
            this.FinalBinary_txb = new System.Windows.Forms.TextBox();
            this.BinaryValue_txb = new System.Windows.Forms.TextBox();
            this.RealValue_txb = new System.Windows.Forms.TextBox();
            this.Random_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(475, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Conversion of Random Real Value to Binary Value";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 229);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(195, 24);
            this.label4.TabIndex = 7;
            this.label4.Text = "Final Binary value : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 24);
            this.label3.TabIndex = 6;
            this.label3.Text = "Binary Value : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = "Real Value : ";
            // 
            // Exit_btn
            // 
            this.Exit_btn.Location = new System.Drawing.Point(544, 223);
            this.Exit_btn.Name = "Exit_btn";
            this.Exit_btn.Size = new System.Drawing.Size(97, 37);
            this.Exit_btn.TabIndex = 15;
            this.Exit_btn.Text = "Exit";
            this.Exit_btn.UseVisualStyleBackColor = true;
            this.Exit_btn.Click += new System.EventHandler(this.Exit_btn_Click);
            // 
            // Convert_btn
            // 
            this.Convert_btn.Location = new System.Drawing.Point(544, 148);
            this.Convert_btn.Name = "Convert_btn";
            this.Convert_btn.Size = new System.Drawing.Size(97, 37);
            this.Convert_btn.TabIndex = 14;
            this.Convert_btn.Text = "Convert";
            this.Convert_btn.UseVisualStyleBackColor = true;
            this.Convert_btn.Click += new System.EventHandler(this.Convert_btn_Click);
            // 
            // FinalBinary_txb
            // 
            this.FinalBinary_txb.Location = new System.Drawing.Point(197, 223);
            this.FinalBinary_txb.Name = "FinalBinary_txb";
            this.FinalBinary_txb.Size = new System.Drawing.Size(341, 36);
            this.FinalBinary_txb.TabIndex = 13;
            // 
            // BinaryValue_txb
            // 
            this.BinaryValue_txb.Location = new System.Drawing.Point(197, 148);
            this.BinaryValue_txb.Name = "BinaryValue_txb";
            this.BinaryValue_txb.Size = new System.Drawing.Size(341, 36);
            this.BinaryValue_txb.TabIndex = 12;
            // 
            // RealValue_txb
            // 
            this.RealValue_txb.Location = new System.Drawing.Point(197, 73);
            this.RealValue_txb.Name = "RealValue_txb";
            this.RealValue_txb.Size = new System.Drawing.Size(198, 36);
            this.RealValue_txb.TabIndex = 11;
            // 
            // Random_btn
            // 
            this.Random_btn.Location = new System.Drawing.Point(544, 73);
            this.Random_btn.Name = "Random_btn";
            this.Random_btn.Size = new System.Drawing.Size(97, 37);
            this.Random_btn.TabIndex = 10;
            this.Random_btn.Text = "Random";
            this.Random_btn.UseVisualStyleBackColor = true;
            this.Random_btn.Click += new System.EventHandler(this.Random_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 291);
            this.Controls.Add(this.Exit_btn);
            this.Controls.Add(this.Convert_btn);
            this.Controls.Add(this.FinalBinary_txb);
            this.Controls.Add(this.BinaryValue_txb);
            this.Controls.Add(this.RealValue_txb);
            this.Controls.Add(this.Random_btn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "102 年工科技競賽第 2 題 隨機實數值轉換為等效二進制值";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Exit_btn;
        private System.Windows.Forms.Button Convert_btn;
        private System.Windows.Forms.TextBox FinalBinary_txb;
        private System.Windows.Forms.TextBox BinaryValue_txb;
        private System.Windows.Forms.TextBox RealValue_txb;
        private System.Windows.Forms.Button Random_btn;
    }
}

