﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _102_2
{
    public partial class Form1 : Form
    {
        public const double MaxValue = 9999.999999;
        public const int MaxDigit = 10;
        public Form1()
        {
            InitializeComponent();
        }

        private void Random_btn_Click(object sender, EventArgs e)
        {
            RealValue_txb.Text = GenerateRandomRealValue().ToString();
        }

        private void Convert_btn_Click(object sender, EventArgs e)
        {
            string binaryValue = "";
            BinaryValue_txb.Text = ConvertRealToBinary(double.Parse(RealValue_txb.Text), ref binaryValue);
            FinalBinary_txb.Text = binaryValue; //組合整數部分與分數部分
        }

        private void Exit_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // 產生 0.0 ~ 9999.999999 之間的隨機實數值
        static double GenerateRandomRealValue()
        {
            Random rnd = new Random();
            return rnd.NextDouble() * MaxValue;
        }

        // 將實數值轉換為二進制值
        static string ConvertRealToBinary(double realValue, ref string binaryValue)
        {
            int integralPart = (int)realValue; // 取整數部分
            double fractionPart = realValue - integralPart; // 取分數部分
            string integralBinary = ConvertIntToBinary(integralPart);// 處理整數部分
            string fractionBinary = ConvertFractionToBinary(fractionPart);// 處理分數部分
            string binaryValueZero = $"{integralBinary}.{fractionBinary}";
            binaryValue = binaryValueZero.TrimEnd('0').TrimEnd('.');// 移除無效的0
            return binaryValueZero;
        }

        // 將整數部分轉換為二進制值
        static string ConvertIntToBinary(int intValue)
        {
            string binary = "";
            while (intValue > 0)
            {
                binary = (intValue % 2) + binary;
                intValue /= 2;
            }
            return binary == "" ? "0" : binary;
        }

        // 將分數部分轉換為二進制值
        static string ConvertFractionToBinary(double fractionValue)
        {
            string binary = "";
            int count = 0;
            while (fractionValue > 0 && count < MaxDigit)
            {
                fractionValue *= 2;
                binary += (int)fractionValue;
                fractionValue -= (int)fractionValue;
                count++;
            }
            return binary;
        }
    }
}
